function [fxi]=NewtIntepoF(n,a,t,h)
xinit=a:h:a+n*h;
yinit=fxreal(xinit);
ylist=zeros(n+1,n+1);
ylist(:,1)=yinit';
for k=1:n
    ylist(:,k+1)=ylist(:,k)-[0;ylist(1:n,k)];
end 
coeff=ones(1,n+1);
for k=1:n
   coeff(k+1)=(t-k+1)/k*coeff(k); 
end
fxi=coeff*(ylist(n+1,:))';
end
function [fxr]=fxreal(x)
%fxr=1./(1+25*x.^2);
fxr=x;
end
