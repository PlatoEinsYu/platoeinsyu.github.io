#include<stdio.h>
#include<math.h>

#define Size 20

float prod(double a[]);


int main()
{
	int n;
	printf("please input integer n\n");
	scanf("%d",&n);
	double initx[Size],inity[Size];
	double x;
	printf("please input %d numbers as initial x\n",n+1);
	for(int i=0;i<n+1;i++)
	{
		scanf("%lf",&initx[i]);
	}
	printf("please input %d numbers as initial y\n",n+1);
	for(int i=0;i<n+1;i++)
	{
		scanf("%lf",&inity[i]);
	}
	printf("please input x that you want interpolate\n");
	scanf("%lf",&x);
	double coef[Size];
	for(int i=0;i<n+1;i++)
	{
		initx[i]=x-initx[i];
	}
	for(int i=0;i<n+1;i++)
	{
		double temp=1;
		for(int j=0;j<n+1;j++)	
		{
			if(j!=i)
			{
				temp=temp*initx[j]/(initx[j]-initx[i]);
			}
		}
		coef[i]=temp;
	}
	double y=0;
	for(int i=0;i<n+1;i++)
	{
		y+=coef[i]*inity[i];	
	}
	printf("The outcome is: %lf\n",y);
}
