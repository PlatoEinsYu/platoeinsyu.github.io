function [fx]=LagIntepo(x,initx,inity)
n=size(initx,2);
initx=x-initx;
coeff=zeros(1,n);
for i=1:n
    coeff(i)=coef(initx,i);
end
fx=coeff*inity';
end
function [ci]=coef(subx,i)
coefx=subx-subx(i);
coefx(i)=1;subx(i)=1;
ci=prod(subx./coefx);
end