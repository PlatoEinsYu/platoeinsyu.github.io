function [fx]=NewtIntepoN(x,initx,inity)
n=size(initx,2)-1;
initx=x-initx
coeff=zeros(1,n+1);
ylist=zeros(n+1,n+1);
ylist(:,1)=inity';
for k=1:n
    ylist(1:n+1-k,k+1)=(ylist(2:n+2-k,k)-ylist(1:n+1-k,k))./((initx(1:n+1-k)-initx(k+1:n+1))');
end 
fx=ylist(1,1);
ylist(:,:);
for i=2:n+1
    fx=fx+prodxx(initx,i-1)*ylist(1,i);
end
end
function [ci]=coef(subx,i)
coefx=subx-subx(i);
coefx(i)=1;subx(i)=1;
ci=prod(subx./coefx);
end
function [y]=prodxx(initx,i)
y=1;
for k=1:i
    y=initx(k)*y;
end
end