#include<stdio.h>
#include<math.h>

float ffd(float x[]);
float func(float x);


int main()
{
	int step=0;
	float x[2];
	float epsi;
	printf("input x0 x1 epsi\n");
	scanf("%f%f%f",&x[0],&x[1],&epsi);
	float delta=x[0]-x[1];
	while (fabs(delta)>epsi)
	{
		delta=ffd(x);
		x[1]=x[0];
		x[0]=x[0]-delta;
		step=step+1;
	}
	printf("the solution is %f \n",x[0]);
	printf("the steps used are %d \n",step);
	return 0;
}
float ffd(float x[])
{
	float y[2];
	y[0]=func(x[0]);
	y[1]=func(x[1]);
	float delta = (x[0]-x[1])*y[0]/(y[0]-y[1]);
	return delta;
}
float func(float x)
{
	return x*x*x-3*x-1;
}

