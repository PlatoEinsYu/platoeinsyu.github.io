#include<stdio.h>
#include<math.h>

float ffd(float x);

int main()
{
	int step=0;
	float x;
	float epsi;
	printf("input x0 epsi\n");
	scanf("%f%f",&x,&epsi);
	float delta=1;
	while (fabs(delta)>epsi)
	{
		delta=ffd(x);
		x=x-delta;
		step=step+1;
	}
	printf("the solution is %f \n",x);
	printf("the steps used are %d \n",step);
	return 0;
}
float ffd(float x)
{
	float f=x*x*x-3*x-1;
	float fd=3*x*x-3;
	return f/fd;
}
