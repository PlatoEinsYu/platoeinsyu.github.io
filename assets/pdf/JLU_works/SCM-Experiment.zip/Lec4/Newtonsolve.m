function [x0,step]=Newtonsolve(x0,epsi)
step=0;
delta=ffd(x0);
while (abs(delta)>epsi)
    delta=(ffd(x0));
    x0=x0-delta;
    step=step+1;
end
end
function [delta]=ffd(x0)
f=x0^3-3*x0-1;
fd=3*x0^2-3;
if fd~=0
    delta=f/fd;
else
    disp('wrong');
end
end