function [x,step]=secsolve(x,epsi)
step=0;
delta=(x(1)-x(2));
while (abs(delta)>epsi)
    delta=(ffd(x));
    x(2)=x(1);
    x(1)=x(1)-delta;
    step=step+1;
end
end
function [delta]=ffd(x)
f=x.^3-3.*x-1;
delta = (x(1)-x(2))*(f(1))/(f(1)-f(2));
end