function [lambda,eigx]=Power_method_H(A)
n=size(A,1);
z=ones(n,3);m=zeros(1,3);
for k=2:3
    z(:,k)=A*z(:,k-1);
    m(k)=max(abs(z(:,k)));
    z(:,k)=z(:,k)/m(k);
end 
pq=[0,0;1,1];
pq(:,2)=pqk(z,m);
for k=1:20
    z(:,1)=A*z(:,3);
    m(1)=max(abs(z(:,1)));
    z(:,1)=z(:,1)/m(1);
    z(:,[1,2,3])=z(:,[2,3,1]);
    m([1,2,3])=m([2,3,1]);
    pq(:,1)=pq(:,2);
    pq(:,2)=pqk(z,m);
end
Relam=-pq(1,1)/2;
Imlam=1/2*sqrt(4*pq(2,1)-pq(1,1)^2);
lambda=Relam+1i*Imlam;
eigx=z(:,1)+1i*(Relam*z(:,1)-m(2)*z(:,2))/Imlam;
end

function [pq1]=pqk(z,m)
pq1=zeros(2,1);
delta=dot(z(:,2),z(:,2))*dot(z(:,1),z(:,1))-dot(z(:,2),z(:,1))^2;
pq1(1)=-m(3)*(dot(z(:,2),z(:,3))*dot(z(:,1),z(:,1))-dot(z(:,1),z(:,2))*dot(z(:,1),z(:,3)))/delta;
pq1(2)=-m(3)*m(2)*(dot(z(:,2),z(:,2))*dot(z(:,1),z(:,3))-dot(z(:,1),z(:,2))*dot(z(:,2),z(:,3)))/delta;
end