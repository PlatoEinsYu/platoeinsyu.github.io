#include<stdio.h>
#include<stdlib.h>
#include<math.h>


double pqk1(double **z,double m[3],int n);
double pqk2(double **z,double m[3],int n);
void Mat_multi(double **Mat,double *z,int n,double *zk);
double fmaxabs(double *z,int n);
void Division(double *z,double m,int n);
void Multiplication(double *z,double m,int n);
double dot(double *z,double *w,int n);

int main()
{
	int n;
	printf("please input matrix size n:\n");
	scanf("%d",&n);
	/* input n */
	
	double **Mat;
	Mat=(double **)calloc(n,sizeof(double*));
	for(int i=0;i<n;i++)
	{
		Mat[i]=(double*)calloc(n,sizeof(double));
	}
	for(int i=0;i<n;i++)
	{
		printf("Please input the %d row\n",i+1);
		for(int j=0;j<n;j++)
		{
			scanf("%lf",&Mat[i][j]);
		}
	}
	
	/* initialize matrix A */
	
	double *z[3];
	for(int i=0;i<3;i++)
	{
		z[i]=(double*)calloc(n,sizeof(double));
	}
	for(int j=0;j<n;j++)
	{
		z[0][j]=1;
	} 
	double m[3]={0};
	/* initialize z */	
	
	for(int k=1;k<3;k++)
	{
		Mat_multi(Mat,z[k-1],n,z[k]);
		m[k]=fmaxabs(z[k],n);
		Division(z[k],m[k],n);
	}
	
	double pq[2][2]={{0,0},{1,1}};
	pq[0][1]=pqk1(z,m,n);
	pq[1][1]=pqk2(z,m,n);
	
	for(int i=0;i<20;i++)
	{
		Mat_multi(Mat,z[2],n,z[0]);
		m[0]=fmaxabs(z[0],n);
		Division(z[0],m[0],n);
		{
		double *tempp;
		tempp=z[0];
		z[0]=z[1];
		z[1]=z[2];
		z[2]=tempp;
		}
		{
		double temp;
		temp=m[0];
		m[0]=m[1];
		m[1]=m[2];
		m[2]=temp;
		}
		{
		pq[0][0]=pq[0][1];
		pq[1][0]=pq[1][1];
		pq[0][1]=pqk1(z,m,n);
		pq[1][1]=pqk2(z,m,n);
		}
	}
	
	double Relam,Imlam;
	Relam=-pq[0][0]/2.0;
	Imlam=(sqrt(4*pq[1][0]-pq[0][0]*pq[0][0]))/2.0;
	printf("Eigenvalue: %lf + i%lf\n",Relam,Imlam);
	
	double *Eigx[2];
	Eigx[0]=z[0];
	Eigx[1]=(double*)calloc(n,sizeof(double));
	for(int k=0;k<n;k++)
	{
		Eigx[1][k]=(Relam*z[0][k]-m[1]*z[1][k])/Imlam;
	}
	printf("The eigenvalue is:\n");
	for(int k=0;k<n;k++)
	{
		printf("%lf + i*%lf \n",Eigx[0][k],Eigx[1][k]);
	}
}

void Mat_multi(double **Mat,double *z,int n,double *zk)
{
	for(int i=0;i<n;i++)
	{
		double sum=0;
		for(int j=0;j<n;j++)
		{
			sum+=Mat[i][j]*z[j];
		}
		zk[i]=sum;
	}
}

double fmaxabs(double *z,int n)
{
	double Max=0;
	for(int i=0;i<n;i++)
	{
		double FABS=fabs(z[i]);
		if(Max<FABS)
		{
			Max=FABS;
		}
	}
	return Max;
}

double dot(double *z,double *w,int n)
{
	double Sum=0;
	for(int i=0;i<n;i++)
	{
		Sum+=z[i]*w[i];
	}
	return Sum;
}

double pqk1(double **z,double m[3],int n)
{
	double delta=0;
	double pq1;
	delta=dot(z[1],z[1],n)*dot(z[0],z[0],n)-dot(z[1],z[0],n)*dot(z[1],z[0],n);
	pq1=-m[2]*(dot(z[1],z[2],n)*dot(z[0],z[0],n)-dot(z[0],z[1],n)*dot(z[0],z[2],n))/delta;
	return pq1;
}

double pqk2(double **z,double m[3],int n)
{
	double delta=0;
	double pq2;
	delta=dot(z[1],z[1],n)*dot(z[0],z[0],n)-dot(z[1],z[0],n)*dot(z[1],z[0],n);
	pq2=-m[2]*m[1]*(dot(z[1],z[1],n)*dot(z[0],z[2],n)-dot(z[0],z[1],n)*dot(z[1],z[2],n))/delta;
	return pq2;
}

void Division(double *z,double m,int n)
{
	for(int i=0;i<n;i++)
	{
		z[i]=z[i]/m;
	}
}

void Multiplication(double *z,double m,int n)
{
	for(int i=0;i<n;i++)
	{
		z[i]=z[i]*m;
	}
}


