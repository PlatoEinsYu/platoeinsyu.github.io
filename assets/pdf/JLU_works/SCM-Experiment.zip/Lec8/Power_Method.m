function [lam]=Power_Method(A)
n=size(A,1);
x=ones(n,1);y=zeros(n,1);
for k=1:20
    y=x/max(abs(x))
    x=A*y
end
[~,index]=max(abs(x));
lam=x(index);
end