function [i,x]=Conjgrad(A,b,N,epsi)
n=size(A,1);
x=zeros(n,1);
r=b-A*x;
p=r;
alpha=(p'*r)/(p'*A*p);
beta=0;
i=0;
delta=1;
while (i<N)&&(epsi<delta)
    x=x+alpha*p;
    delta=norm(alpha*p);
    r=r-alpha*A*p;
    beta=(p'*A*r)/(p'*A*p);
    p=r-beta*p;
    alpha=(p'*r)/(p'*A*p);
    i=i+1;
end
end
