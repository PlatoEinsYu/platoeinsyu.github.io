function [v,i,x]=GaussSeidel(A,b,N,epsi)
n=size(A,1);
U=-triu(A,1);
H=(A+U)\U;
b=(A+U)\b;
x0=zeros(n,2);
i=0;
delta=1;
K=norm(H)/(1-norm(H));
v=-log(vrho(H));
while((delta>epsi)&&(i<N))
    x0(:,2)=x0(:,1);
    x0(:,1)=H*x0(:,2)+b;
    delta=K*norm(x0(:,1)-x0(:,2));
    i=i+1;
end
x=x0(:,1);
end
