function [i,x]=SDM(A,b,N,epsi)
n=size(A,1);
x=zeros(n,1);
r=b-A*x;
delta=1;
i=0;
tau=0;
while (i<N)&&(epsi<delta)
    tau=((r'*r)/(r'*A*r));
    x=x+tau*r;
    r=b-A*x;
    i=i+1;
    delta=norm(tau*r);
end
end