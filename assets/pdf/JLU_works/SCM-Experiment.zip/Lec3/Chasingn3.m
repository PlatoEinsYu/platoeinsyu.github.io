function [x]=Chasingn3(A,b)
n=size(A,1);
[L,U]=decom(A,n);
y=solveL(L,b,n);
x=solveU(U,y,n);
end
function [L,U]=decom(A,n)
L=ones(n,2);
L(1,1)=0;
U=A(:,[2,3]);
%Done
U(1,1)=A(1,2);
for i=2:n
    L(i,1)=A(i,1)/U(i-1,1);
    U(i,1)=A(i,2)-L(i,1)*A(i-1,3);
end
end
function [y]=solveL(L,b,n)
y=zeros(n,1);
y(1)=b(1);
for i=2:n
    y(i)=b(i)-L(i,1)*y(i-1);
end
end
function [x]=solveU(U,y,n)
x=zeros(n,1);
x(n)=y(n)/U(n,1);
for i=n-1:-1:1
    x(i)=(y(i)-U(i,2)*x(i+1))/U(i,1);
end
end