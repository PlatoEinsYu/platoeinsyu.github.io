n=100;
%A=diag(repmat([-4],n,1),0)+diag(repmat([1],n-1,1),1)+diag(repmat([1],n-1,1),-1)
A=ones(n,3);A(:,2)=-4*A(:,2);A(1,1)=0;A(n,3)=0
b=-15*ones(n,1);
b(1)=-27