k=100;
x=zeros(1,k+1);
for n=6:1:6+k
    %diag(repmat([3], 1, n))+diag(repmat([1], 1, n-1), 1)+diag(repmat([9], 1, n-1), -1);
    x(1,n-5)=cond(diag(repmat([3], 1, n))+diag(repmat([1], 1, n-1), 1)+diag(repmat([9], 1, n-1), -1));
end
plot([6:1:k+6],x,'b');
    