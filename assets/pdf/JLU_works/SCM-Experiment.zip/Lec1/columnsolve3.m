function [x]=columnsolve3(n)
%��Ȼ˳��
x=zeros(n,1);
A=diag(repmat([3], 1, n))+diag(repmat([1], 1, n-1), 1)+diag(repmat([9], 1, n-1), -1);
b=13*ones(n,1);b(n)=12;b(1)=4;
eig(A);
x=A\b;