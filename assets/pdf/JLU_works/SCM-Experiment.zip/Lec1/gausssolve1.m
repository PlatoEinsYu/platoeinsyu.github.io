function [x]=gausssolve1(n)
x=zeros(n,1);
flag=0;
%initialize x
A=diag(repmat([3], 1, n))+diag(repmat([1], 1, n-1), 1)+diag(repmat([9], 1, n-1), -1);
b=13*ones(n,1);b(n)=12;b(1)=4;
%initialize A and b
for k=1:n
    if det(A(1:k,1:k))==0
        flag=1;
        break
    end
end %test principle minor
if flag==0
    for k=1:1:n-1
        for j=k+1:1:n
            A(j,k)=A(j,k)/A(k,k);
            A(j,k+1:n)=A(j,k+1:n)-A(j,k)*A(k,k+1:n);
            b(j)=b(j)-A(j,k)*b(k);
        end
    end %if all are nonsingular, the method applies
    x(n)=b(n)/A(n,n);
    for k=n-1:-1:1
        x(k)=(b(k)-A(k,k+1:n)*x(k+1:n))/A(k,k);
    end
else
    disp('Can not use gaussian method!');
    %if not
end
end