#include<stdio.h>
#include<math.h>

#define SIZE 20

double prod(double a[],int k);

int main()
{
	//initial size n
	int n;
	printf("please initialize size n<20;\n");
	scanf("%d",&n);
	
	//input initx and inity
	printf("please initialize x (ascending) (size=%d)\n",n);
	double initx[SIZE];
	for(int i=0;i<n;i++)
	{
		scanf("%lf",&initx[i]);
	}
	
	printf("please initialize y (size=%d)\n",n);
	double inity[SIZE];
	for(int i=0;i<n;i++)
	{
		scanf("%lf",&inity[i]);
	}

	//initialize x;
	printf("input x where you want approximate\n");
	double x;
	scanf("%lf",&x);
	
	//process x
	for(int i=0;i<n;i++)
	{
		initx[i]=x-initx[i];
	}
	

	//initialize Ylist
	double Ylist[SIZE][SIZE]={0};
	for(int i=0;i<n;i++)
	{
		Ylist[i][0]=inity[i];
	}
	//Difference
	for(int i=1;i<n;i++)
	{
		for(int j=0;j<n-i;j++)
		{
			Ylist[j][i]=-(Ylist[j+1][i-1]-Ylist[j][i-1])/(initx[j+i]-initx[j]);
		}
	}
	double finaly=1;
	finaly*=Ylist[0][0];
	for(int i=1;i<n;i++)
	{
		finaly+=prod(initx,i)*Ylist[0][i];
	} 
	
	printf("The value is %lf",finaly);
}

double prod(double a[],int k)
{
	double product=1;
	for(int i=0;i<k;i++)
	{
		product*=a[i];
	}
	return product;
}
