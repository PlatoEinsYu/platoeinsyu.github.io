function [fx]=NewtIntepo(x,initx,inity)
n=size(initx,2)-1;
initx=x-initx;
coeff=zeros(1,n+1);
ylist=zeros(n+1,n+1);
ylist(:,1)=inity';
for k=1:n
    ylist(1:n+1-k,k+1)=(ylist(2:n+2-k,k)-ylist(1:n+1-k,k))./((initx(1:n+1-k)-initx(k+1:n+1))');
end %��ֵ����
for i=2:n+1
    coeff(i)=prod(initx(1,1:i-1));
end
coeff(1)=1;
fx=coeff*ylist(1,:)';
end
