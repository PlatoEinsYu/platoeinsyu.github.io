function [integral]=Romberg(m,a,b)
Rom=(2^6*Cotes(2*m,a,b)-Cotes(m,a,b))/(2^6-1);
integral=Rom;
end

function [f]=Infunc(x) %evaluate
f=exp(x).*sin(x);
end

function [Q1]=Trapezoid(m,a,b)
h=(b-a)/m;
x=linspace(a,b,m+1);
y=Infunc(x);
Q1=h/2*(2*sum(y)-y(1)-y(m+1));
end

function [Q2]=Simpson(m,a,b) %2m
Q2=(4*Trapezoid(2*m,a,b)-Trapezoid(m,a,b))/(4-1);
end

function [Q4]=Cotes(m,a,b)
Q4=(2^4*Simpson(2*m,a,b)-Simpson(m,a,b))/(2^4-1);
end