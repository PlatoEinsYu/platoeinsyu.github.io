#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double sum(double a[],int m);
double *Infunc(double x[],int m,double trans);

int main()
{
	double m;
	double a,b;
	double integral;
	scanf("%lf",&m);
	scanf("%lf%lf",&a,&b);
	
	double *x;
	x=(double *)calloc(m,sizeof(double));
	for(int k=0;k<m;k++)
	{
		x[k]=a+k*(b-a)/m+1/m;
	}
	
	double S1,S2;
	S1=sum(Infunc(x,m,1/(m*sqrt(3))),m)/m;
	S2=sum(Infunc(x,m,-1/(m*sqrt(3))),m)/m;
	integral=S1+S2;
	
	printf("%lf",integral);

	return 0;
}

double sum(double a[],int m)
{
	double sum=0;
	for(int k=0;k<m;k++)
	{
		sum+=a[k];
	}
	return sum;
}

double *Infunc(double x[],int m,double trans)
{
	double *Infunc;
	Infunc=(double *)calloc(m,sizeof(double));
	for(int k=0;k<m;k++)
	{
		Infunc[k]=4/(1+(x[k]+trans)*(x[k]+trans));
	}
	
	return Infunc;
}

realname:"冯诗�?