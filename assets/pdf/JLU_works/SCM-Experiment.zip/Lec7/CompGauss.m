function [integral]=CompGauss(m,a,b)
x=linspace(1/m,2-1/m,m);
S1=(sum(Infunc(x+1/(sqrt(3)*m))))/m;
S2=(sum(Infunc(x-1/(sqrt(3)*m))))/m;
integral=S1+S2;
end

function [y]=Infunc(x)
y=4./(1+x.^2);
end