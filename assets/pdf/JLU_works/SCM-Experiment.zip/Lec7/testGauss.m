function [m]=testGauss()
m=1;
S1=CompGauss(m);
S2=CompGauss(m+1);
while(abs(S1-S2)>1e-5)
    S1=CompGauss(m);
    S2=CompGauss(m+1);
    m=m+1;
end
end