# JLUThesis - 吉林大学LaTeX论文模板
此项目提供用于排版吉林大学 本科生 毕业论文的LaTeX模板。
基于 2019级 通信工程学院 模板制作。

## 样例展示
<p align = "center">
  <img src = "https://user-images.githubusercontent.com/78149191/201933177-8abdce74-9191-4b18-8f1f-fc5129d6a306.png">
</p>
<br>

[样例PDF](https://github.com/Sakura-shem/JLUThesis/blob/master/main.pdf)

## Todo
- 优化细节。
- 开题报告模板。
欢迎提交 Pull Request。

## 致谢
- [bjtuThesis](https://github.com/csarron/bsThesisWHU)