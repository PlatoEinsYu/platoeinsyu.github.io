# HEBUT-Beamer-Theme

本模板改自 [https://github.com/KveinAxel/JLU-Beamer-Theme](https://github.com/KveinAxel/JLU-Beamer-Theme) 和 
 [https://github.com/Trinkle23897/THU-Beamer-Theme](https://github.com/Trinkle23897/THU-Beamer-Theme)
 
最初能追溯到的版本是 [https://www.latexstudio.net/archives/4051.html](https://www.latexstudio.net/archives/4051.html)

其中的教程部分参考了大鹰团长的介绍：[https://tuna.moe/event/2018/latex/](https://tuna.moe/event/2018/latex/)

颜色搭配参考了学校[视觉形象标识系统](https://www.hebut.edu.cn/tzgg/49617.htm)的要求。

已上传[Overleaf Gallery](https://www.overleaf.com/latex/templates/beamer-theme-for-hebut/dmktyqsqppwg)
